﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace STEP3_1
{
    public partial class CallDLLForm : Form
    {
        // DLLを読み込む
        [DllImport("HelloDLL.dll")]
        private extern static void HelloWorld();

        public CallDLLForm()
        {
            InitializeComponent();
        }

        // ボタンを押下した時の処理
        private void CallDllBtn_Click(object sender, EventArgs e)
        {
            // DLLで作成したメソッドを呼び出す
            HelloWorld();
        }
    }
}
